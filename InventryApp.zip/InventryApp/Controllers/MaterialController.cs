﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InventryApp.Controllers
{
    public class MaterialController : Controller
    {
        // GET: Material
        public ActionResult Index()
        {
            List<tblMaterial> objList = new List<tblMaterial>();
            using (var ctx = new indentryDbEntities())
            {
                objList = ctx.tblMaterials.ToList();
            }
            return View(objList);
        }
        public ActionResult add()
        {
            
            return View();
        }
        [HttpPost]
        public ActionResult add(tblMaterial obj)
        {
            using (var ctx = new indentryDbEntities())
            {
                obj.CreatedBy = 1;
                obj.CreatedOn = DateTime.Now;
                obj = ctx.tblMaterials.Add(obj);
                ctx.SaveChanges();
            }
            return View();
        }
        public ActionResult Edit(int id)
        {
            using (var ctx = new indentryDbEntities()) 
            {
                tblMaterial obj = ctx.tblMaterials.Find(id);
                if (obj!=null)
                {
                    return View(obj);
                }
            }
            return RedirectToAction("Index");
        }
        [HttpPost]
        public ActionResult Edit(tblMaterial obj)
        {
            using (var ctx = new indentryDbEntities())
            {
                obj.CreatedOn = DateTime.Now;
                obj.CreatedBy = 1;
                ctx.tblMaterials.Attach(obj);
                ctx.Entry(obj).State = System.Data.Entity.EntityState.Modified;
                ctx.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            using (var ctx = new indentryDbEntities())
            {
                tblMaterial obj = ctx.tblMaterials.Find(id);
                if (obj != null)
                {
                    ctx.tblMaterials.Remove(obj);
                    ctx.SaveChanges();

                }
            }
            return RedirectToAction("Index");
        }
    }
}