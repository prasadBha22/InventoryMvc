﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InventryApp.Controllers
{
    public class POMasterController : Controller
    {
        // GET: POMasterList
        public ActionResult Index()
        {
            List<tblPOMaster> PoMasterList = new List<tblPOMaster>();
            using (var ctx = new indentryDbEntities())
            {

                PoMasterList = ctx.tblPOMasters.ToList();
              
            }
                return View(PoMasterList);
        }

        public ActionResult add()
        {
            return View();
        }
        //add new entry to DB
        [HttpPost]
        public ActionResult add(tblPOMaster obj)
        {
            using (var ctx = new indentryDbEntities())
            {
               obj =  ctx.tblPOMasters.Add(obj);
                ctx.SaveChanges();
            }
            return RedirectToAction("Index");
        }
        //get value to edit form 
        public ActionResult Edit(int id)
        {
            using (var ctx = new indentryDbEntities())
            {
               tblPOMaster obj =  ctx.tblPOMasters.Find(id);
                if (obj != null)
                {
                    return View(obj);
                }
            }
            return RedirectToAction("Index");
        }
        //add data into database
        [HttpPost]
        public ActionResult Edit(tblPOMaster obj)
        {
            using (var ctx = new indentryDbEntities())
            {
                ctx.tblPOMasters.Attach(obj);
                ctx.Entry(obj).State = System.Data.Entity.EntityState.Modified;
                ctx.SaveChanges();
            }
            return RedirectToAction("Index");
        }
        //Delete Record from DB
        public ActionResult Delete(int id)
        {
            using (var ctx = new indentryDbEntities())
            {
                tblPOMaster obj = ctx.tblPOMasters.Find(id);
                if (obj != null)
                {
                    ctx.tblPOMasters.Remove(obj);
                    ctx.SaveChanges();
                }
            }
            return RedirectToAction("Index");
        }
    }
}