﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InventryApp.Controllers
{
    public class VendorController : Controller
    {
        // GET: VendorList
        public ActionResult Index()
        {
            List<tblVender> venderList = new List<tblVender>();
            using (var ctx = new indentryDbEntities())
            {
                venderList = ctx.tblVenders.ToList();
            }
            return View(venderList);
        }

        public ActionResult add()
        {
            return View();
        }
        [HttpPost]
        public ActionResult add(tblVender obj)
        {
            using (var ctx = new indentryDbEntities())
            {
                obj.CreatedOn = DateTime.Now;
                obj.CreatedBy = 1;
                obj = ctx.tblVenders.Add(obj);
                ctx.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public ActionResult Edit(int id)
        {
            using (var ctx = new indentryDbEntities())
            {
                tblVender obj = ctx.tblVenders.Find(id);
                if (obj != null)
                {
                    return View(obj);
                }
            }
            return RedirectToAction("Index");
        }
        [HttpPost]
        public ActionResult Edit(tblVender obj)
        {
            using (var ctx = new indentryDbEntities())
            {

                obj.CreatedOn = DateTime.Now;
                obj.CreatedBy = 1;
                ctx.tblVenders.Attach(obj);
                ctx.Entry(obj).State = System.Data.Entity.EntityState.Modified;
                ctx.SaveChanges();


            }
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            using (var ctx = new indentryDbEntities())
            {
                tblVender obj = ctx.tblVenders.Find(id);
                if (obj != null)
                {
                   
                    ctx.tblVenders.Remove(obj);
                    ctx.SaveChanges();
                }
            }
            return RedirectToAction("Index");
        }
    }
}